package org.example.kurs.configuration;

import lombok.RequiredArgsConstructor; // Аннотация Lombok для автоматического создания конструктора с финальными полями.
import org.springframework.context.annotation.Bean; // Аннотация для создания бина в контексте Spring.
import org.springframework.context.annotation.Configuration; // Указывает, что этот класс — конфигурационный.
import org.springframework.security.authentication.AuthenticationManager; // Управляет процессом аутентификации.
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration; // Конфигурация аутентификации.
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity; // Включает аннотации для контроля доступа на уровне методов.
import org.springframework.security.config.annotation.web.builders.HttpSecurity; // Класс для настройки безопасности HTTP-запросов.
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer; // Используется для кастомизации стандартных конфигураций.
import org.springframework.security.config.http.SessionCreationPolicy; // Определяет политику создания сессий.
import org.springframework.security.core.userdetails.UserDetailsService; // Интерфейс для работы с данными пользователей.
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; // Класс для шифрования паролей с помощью алгоритма BCrypt.
import org.springframework.security.crypto.password.PasswordEncoder; // Интерфейс для кодирования паролей.
import org.springframework.security.web.SecurityFilterChain; // Настройка цепочки фильтров безопасности.
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter; // Фильтр для аутентификации по логину и паролю.

@Configuration // Помечает класс как конфигурационный для Spring.
@EnableMethodSecurity // Включает безопасность на уровне методов через аннотации.
@RequiredArgsConstructor // Автоматически создает конструктор для всех финальных полей класса.
public class SecurityConfig {

    // Провайдер токенов JWT для проверки и создания токенов.
    private final JwtTokenProvider jwtTokenProvider;

    // Сервис для работы с данными пользователей.
    private final UserDetailsService userDetailsService;

    /**
     * Создает бин для фильтра JWT.
     * @return JwtTokenFilter - фильтр для обработки JWT-токенов.
     */
    @Bean
    public JwtTokenFilter jwtTokenFilter() {
        return new JwtTokenFilter(jwtTokenProvider, userDetailsService);
    }

    /**
     * Конфигурация цепочки безопасности.
     * @param http - объект для настройки безопасности HTTP-запросов.
     * @return SecurityFilterChain - цепочка фильтров безопасности.
     * @throws Exception - исключение при ошибке конфигурации.
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable) // Отключает защиту CSRF, так как используется Stateless-аутентификация.
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)) // Устанавливает Stateless-сессии.
                .authorizeHttpRequests(authz -> authz
                        .requestMatchers("/auth/login",  "/auth/register").permitAll() // Разрешает доступ к эндпоинтам для входа и регистрации.
                        .anyRequest().authenticated() // Все остальные запросы требуют аутентификации.
                )
                .addFilterBefore(jwtTokenFilter(), UsernamePasswordAuthenticationFilter.class); // Добавляет фильтр JWT перед фильтром аутентификации по логину и паролю.
        return http.build(); // Собирает и возвращает цепочку фильтров.
    }

    /**
     * Создает бин для менеджера аутентификации.
     * @param authenticationConfiguration - конфигурация для получения менеджера аутентификации.
     * @return AuthenticationManager - менеджер аутентификации.
     * @throws Exception - исключение при ошибке получения менеджера аутентификации.
     */
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    /**
     * Создает бин для шифрования паролей.
     * @return PasswordEncoder - объект для шифрования паролей с использованием BCrypt.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12); // Указывает количество раундов шифрования (12).
    }
}