package org.example.kurs.configuration;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Фильтр для обработки JWT токенов в каждом HTTP-запросе.
 * Расширяет OncePerRequestFilter, чтобы гарантировать, что фильтр будет применяться
 * один раз за запрос.
 */
@RequiredArgsConstructor
public class JwtTokenFilter extends OncePerRequestFilter {

    // Провайдер токенов для валидации и получения данных токена
    private final JwtTokenProvider jwtTokenProvider;
    // Сервис для получения данных о пользователе (опционально, в зависимости от логики)
    private final UserDetailsService userDetailsService;

    /**
     * Основной метод, обрабатывающий HTTP-запрос.
     * Проверяет наличие и валидность токена, устанавливает аутентификацию в SecurityContext.
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {
        // Извлекаем токен из заголовка Authorization
        String token = resolveToken(request);

        // Проверяем валидность токена
        if (token != null && jwtTokenProvider.validateToken(token)) {
            // Устанавливаем аутентификацию в контекст безопасности
            SecurityContextHolder.getContext().setAuthentication(jwtTokenProvider.getAuthentication(token));
        }

        // Продолжаем выполнение цепочки фильтров
        filterChain.doFilter(request, response);
    }

    /**
     * Извлекает токен из заголовка Authorization.
     * Ожидается, что токен будет в формате "Bearer <токен>".
     */
    private String resolveToken(HttpServletRequest request) {
        // Получаем значение заголовка Authorization
        String bearerToken = request.getHeader("Authorization");
        // Проверяем, что заголовок не пустой и начинается с "Bearer "
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            // Возвращаем только сам токен (без префикса "Bearer ")
            return bearerToken.substring(7);
        }
        // Если токена нет или он некорректный, возвращаем null
        return null;
    }
}