package org.example.kurs.model;

import jakarta.persistence.*; // Импорт аннотаций для работы с JPA.
import lombok.AllArgsConstructor; // Аннотация для создания конструктора со всеми параметрами.
import lombok.Getter; // Аннотация для автоматической генерации геттеров.
import lombok.NoArgsConstructor; // Аннотация для создания конструктора без параметров.
import lombok.Setter; // Аннотация для автоматической генерации сеттеров.

import java.util.List; // Для работы с коллекцией списка.

@Entity // Указывает, что этот класс является сущностью JPA и будет отображен в таблице базы данных.
@Table(name = "users") // Устанавливает имя таблицы в базе данных, соответствующей сущности.
@Getter // Генерирует геттеры для всех полей.
@Setter // Генерирует сеттеры для всех полей.
@AllArgsConstructor // Создает конструктор с параметрами для всех полей.
@NoArgsConstructor // Создает конструктор без параметров.
public class ApplicationUser {

    @Id // Указывает, что поле id является уникальным идентификатором (primary key).
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Устанавливает автоинкремент для id.
    private Long id;

    private String username; // Имя пользователя.
    private String password; // Пароль пользователя.
    private String email; // Электронная почта пользователя.

    @Enumerated(EnumType.STRING) // Указывает, что роль должна быть сохранена в базе данных как строка.
    private ApplicationRole role; // Роль пользователя, которая ссылается на перечисление ApplicationRole.

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL) // Отношение "один ко многим", указывающее, что у пользователя может быть несколько лицензий.
    private List<License> licenses; // Список лицензий пользователя.

    // Геттеры и сеттеры для полей уже генерируются с помощью Lombok-аннотаций, но также можно вручную указать их, если необходимо:
    public String getUsername() {
        return username; // Возвращает имя пользователя.
    }

    public void setUsername(String username) {
        this.username = username; // Устанавливает имя пользователя.
    }

    public String getPassword() {
        return password; // Возвращает пароль пользователя.
    }

    public void setPassword(String password) {
        this.password = password; // Устанавливает пароль пользователя.
    }

    public String getEmail() {
        return email; // Возвращает email пользователя.
    }

    public void setEmail(String email) {
        this.email = email; // Устанавливает email пользователя.
    }
}