package org.example.kurs.model;

import lombok.AllArgsConstructor; // Аннотация для автоматического создания конструктора с параметрами.
import lombok.Getter; // Аннотация для генерации геттеров для всех полей.
import org.springframework.security.core.GrantedAuthority; // Интерфейс для представления полномочий (разрешений).
import org.springframework.security.core.authority.SimpleGrantedAuthority; // Класс для представления полномочий (с простым названием).

import java.util.HashSet; // Для работы с множествами.
import java.util.Set; // Коллекция для хранения уникальных элементов.
import java.util.stream.Collectors; // Для работы с потоками и сбора элементов.

@Getter // Генерирует геттеры для всех полей в классе.
@AllArgsConstructor // Генерирует конструктор с параметрами для всех полей.
public enum ApplicationRole {
    // Перечисление ролей с разрешениями для каждой роли.
    USER(Set.of(Permission.READ)), // Роль USER имеет разрешение на чтение.
    ADMIN(Set.of(Permission.READ, Permission.MODIFICATION)); // Роль ADMIN имеет разрешения на чтение и модификацию.

    private final Set<Permission> permissions; // Множество разрешений для каждой роли.

    /**
     * Получение списка полномочий, которые соответствуют данной роли.
     * @return Set<GrantedAuthority> - множество полномочий, включая роль пользователя.
     */
    public Set<GrantedAuthority> getGrantedAuthorities() {
        // Преобразуем разрешения в объект SimpleGrantedAuthority.
        Set<GrantedAuthority> grantedAuthorities = permissions.stream()
                .map(permission -> new SimpleGrantedAuthority(permission.getPermission())) // Преобразуем каждое разрешение.
                .collect(Collectors.toSet()); // Собираем в множество.

        // Добавляем роль пользователя как полномочие (например, ROLE_USER или ROLE_ADMIN).
        grantedAuthorities.add(new SimpleGrantedAuthority("ROLE_" + name())); // Добавляем префикс ROLE_ к имени роли.
        return grantedAuthorities; // Возвращаем итоговое множество полномочий.
    }
}