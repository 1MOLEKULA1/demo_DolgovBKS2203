package org.example.kurs.controller;

import lombok.RequiredArgsConstructor; // Аннотация для автоматического создания конструктора с финальными полями.
import org.springframework.http.HttpStatus; // Статус HTTP-ответа.
import org.springframework.http.ResponseEntity; // Класс для формирования HTTP-ответа.
import org.springframework.security.authentication.AuthenticationManager; // Управляет процессом аутентификации.
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken; // Токен для проверки логина и пароля.
import org.springframework.security.core.AuthenticationException; // Исключение, выбрасываемое при ошибках аутентификации.
import org.springframework.security.core.userdetails.UsernameNotFoundException; // Исключение, выбрасываемое, если пользователь не найден.
import org.springframework.web.bind.annotation.*; // Аннотации для создания REST-контроллеров.
import org.example.kurs.configuration.JwtTokenProvider; // Класс для работы с JWT-токенами.
import org.example.kurs.model.ApplicationUser; // Модель данных пользователя.
import org.example.kurs.model.AuthenticationRequest; // Модель запроса на аутентификацию.
import org.example.kurs.model.AuthenticationResponse; // Модель ответа на успешную аутентификацию.
import org.example.kurs.repository.ApplicationUserRepository; // Репозиторий для работы с данными пользователей.

@RestController // Указывает, что этот класс — REST-контроллер.
@RequestMapping("/auth") // Указывает базовый URL для всех методов контроллера.
@RequiredArgsConstructor // Автоматически создает конструктор для финальных полей.
public class AuthenticationController {

    // Репозиторий для получения данных о пользователях.
    private final ApplicationUserRepository ApplicationUserRepository;

    // Менеджер аутентификации, проверяет логин и пароль.
    private final AuthenticationManager authenticationManager;

    // Провайдер JWT-токенов, создает и проверяет токены.
    private final JwtTokenProvider jwtTokenProvider;

    /**
     * Метод для входа пользователя.
     * @param request - объект с данными для аутентификации (email и пароль).
     * @return ResponseEntity - HTTP-ответ с токеном или сообщением об ошибке.
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthenticationRequest request) {
        try {
            // Извлекаем email из запроса.
            String email = request.getEmail();

            // Находим пользователя по email или выбрасываем исключение.
            ApplicationUser user = ApplicationUserRepository.findByEmail(email)
                    .orElseThrow(() -> new UsernameNotFoundException("User not found"));

            // Аутентифицируем пользователя с использованием email и пароля.
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            email, request.getPassword()
                    )
            );

            // Генерируем JWT-токен для аутентифицированного пользователя.
            String token = jwtTokenProvider.createToken(email, user.getRole().getGrantedAuthorities());

            // Возвращаем успешный ответ с токеном.
            return ResponseEntity.ok(new AuthenticationResponse(email, token));
        } catch (AuthenticationException ex) {
            // Возвращаем ответ с ошибкой, если аутентификация не удалась.
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid email or password");
        }
    }
}