package org.example.kurs.controller;

import org.example.kurs.model.Product; // Модель данных для продукта.
import org.example.kurs.service.ProductService; // Сервис для работы с продуктами.
import org.springframework.beans.factory.annotation.Autowired; // Аннотация для автоматической инъекции зависимостей.
import org.springframework.http.HttpStatus; // Статусы HTTP-ответов.
import org.springframework.http.ResponseEntity; // Класс для формирования HTTP-ответов.
import org.springframework.web.bind.annotation.*; // Аннотации для создания REST-контроллеров.

import java.util.List; // Для работы со списками.
import java.util.Optional; // Для обработки объектов, которые могут быть null.

@RestController // Указывает, что данный класс является REST-контроллером.
@RequestMapping("/api/products") // Устанавливает базовый URL для всех методов контроллера.
public class ProductController {

    private final ProductService productService; // Сервис для работы с бизнес-логикой продуктов.

    // Конструктор с аннотацией @Autowired для внедрения зависимостей.
    @Autowired
    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    /**
     * Создание или обновление продукта.
     * @param product - объект продукта, переданный в теле запроса.
     * @return ResponseEntity<Product> - созданный или обновленный продукт с HTTP-статусом 201 (Created).
     */
    @PostMapping
    public ResponseEntity<Product> createOrUpdateProduct(@RequestBody Product product) {
        Product savedProduct = productService.saveProduct(product); // Сохраняем или обновляем продукт.
        return ResponseEntity.status(HttpStatus.CREATED).body(savedProduct); // Возвращаем созданный продукт.
    }

    /**
     * Получение продукта по ID.
     * @param id - уникальный идентификатор продукта.
     * @return ResponseEntity<Product> - найденный продукт или статус 404 (Not Found).
     */
    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        Optional<Product> product = productService.getProductById(id); // Ищем продукт по ID.
        return product.map(ResponseEntity::ok) // Если найден, возвращаем продукт со статусом 200 (OK).
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build()); // Если нет, возвращаем статус 404.
    }

    /**
     * Получение списка всех продуктов.
     * @return ResponseEntity<List<Product>> - список всех продуктов со статусом 200 (OK).
     */
    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = productService.getAllProducts(); // Получаем все продукты.
        return ResponseEntity.ok(products); // Возвращаем список продуктов.
    }

    /**
     * Удаление продукта по ID.
     * @param id - уникальный идентификатор продукта.
     * @return ResponseEntity<Void> - статус 204 (No Content), если удаление успешно, или 404 (Not Found), если продукт не найден.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable Long id) {
        Optional<Product> product = productService.getProductById(id); // Проверяем, существует ли продукт.
        if (product.isPresent()) {
            productService.deleteProduct(id); // Удаляем продукт.
            return ResponseEntity.noContent().build(); // Возвращаем статус 204 (No Content).
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build(); // Возвращаем статус 404 (Not Found), если продукт не найден.
        }
    }
}