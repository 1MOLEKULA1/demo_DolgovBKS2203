package org.example.kurs.controller;

import org.example.kurs.model.License; // Модель данных для лицензий.
import org.example.kurs.repository.LicenseRepository; // Репозиторий для работы с данными лицензий.
import org.springframework.beans.factory.annotation.Autowired; // Аннотация для автоматической инъекции зависимостей.
import org.springframework.web.bind.annotation.*; // Аннотации для создания REST-контроллеров.

import java.util.List; // Для работы со списками.
import java.util.Optional; // Для работы с объектами, которые могут быть null.

@RestController // Указывает, что этот класс является REST-контроллером.
@RequestMapping("/api/licenses") // Устанавливает базовый URL для всех методов контроллера.
public class LicenseController {

    @Autowired // Аннотация для автоматической инъекции экземпляра LicenseRepository.
    private LicenseRepository licenseRepository;

    /**
     * Получить список всех лицензий.
     * @return List<License> - список всех лицензий из базы данных.
     */
    @GetMapping
    public List<License> getAllLicenses() {
        return licenseRepository.findAll();
    }

    /**
     * Получить лицензию по ID.
     * @param id - уникальный идентификатор лицензии.
     * @return License - объект лицензии или null, если лицензия не найдена.
     */
    @GetMapping("/{id}")
    public License getLicenseById(@PathVariable Long id) {
        Optional<License> license = licenseRepository.findById(id); // Ищем лицензию по ID.
        return license.orElse(null); // Возвращаем объект или null, если лицензия не найдена.
    }

    /**
     * Создать новую лицензию.
     * @param license - объект лицензии, переданный в теле запроса.
     * @return License - сохраненная лицензия.
     */
    @PostMapping
    public License createLicense(@RequestBody License license) {
        return licenseRepository.save(license); // Сохраняем объект в базу данных.
    }

    /**
     * Обновить существующую лицензию.
     * @param id - уникальный идентификатор лицензии.
     * @param license - объект лицензии с новыми данными.
     * @return License - обновленная лицензия.
     */
    @PutMapping("/{id}")
    public License updateLicense(@PathVariable Long id, @RequestBody License license) {
        license.setId(id); // Устанавливаем ID лицензии, чтобы обновить существующую запись.
        return licenseRepository.save(license); // Сохраняем изменения в базу данных.
    }

    /**
     * Удалить лицензию по ID.
     * @param id - уникальный идентификатор лицензии.
     */
    @DeleteMapping("/{id}")
    public void deleteLicense(@PathVariable Long id) {
        licenseRepository.deleteById(id); // Удаляем запись из базы данных.
    }
}