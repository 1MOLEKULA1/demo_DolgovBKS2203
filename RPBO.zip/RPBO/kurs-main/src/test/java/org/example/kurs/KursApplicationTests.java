package org.example.kurs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KursApplicationTests {

    @Test
    void contextLoads() {
    }

}
